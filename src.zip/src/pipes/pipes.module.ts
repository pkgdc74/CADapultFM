import { NgModule } from '@angular/core';
import { TimeUsedPipe } from './time-used/time-used';
@NgModule({
	declarations: [TimeUsedPipe],
	imports: [],
	exports: [TimeUsedPipe]
})
export class PipesModule {}
